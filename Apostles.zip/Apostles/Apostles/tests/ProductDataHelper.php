<?php
/**
 * Helper class to provide sample product data for testing
 */
class ProductDataHelper
{
    /**
     * Get a sample array of products for testing
     * 
     * @return array
     */
    public static function getSampleProducts()
    {
        return [
            [
                'id' => 1,
                'name' => 'Rice',
                'sku' => 'GRN-001',
                'category' => 'Grains',
                'buyingPrice' => 45.00,
                'expiryDate' => '2025-12-31',
                'quantity' => 42,
                'unit' => 'kg',
                'lastUpdate' => '2025-05-15'
            ],
            [
                'id' => 2,
                'name' => 'Cooking Oil',
                'sku' => 'OIL-002',
                'category' => 'Oil',
                'buyingPrice' => 120.50,
                'expiryDate' => '2025-10-15',
                'quantity' => 15,
                'unit' => 'bottles',
                'lastUpdate' => '2025-05-14'
            ],
            [
                'id' => 3,
                'name' => 'Spaghetti',
                'sku' => 'PST-003',
                'category' => 'Pasta',
                'buyingPrice' => 35.75,
                'expiryDate' => '2026-01-20',
                'quantity' => 30,
                'unit' => 'packs',
                'lastUpdate' => '2025-05-12'
            ],
            [
                'id' => 4,
                'name' => 'Coffee',
                'sku' => 'BEV-004',
                'category' => 'Beverages',
                'buyingPrice' => 180.00,
                'expiryDate' => '2025-08-30',
                'quantity' => 8,
                'unit' => 'jars',
                'lastUpdate' => '2025-05-10'
            ],
            [
                'id' => 5,
                'name' => 'Canned Tuna',
                'sku' => 'CAN-005',
                'category' => 'Canned Goods',
                'buyingPrice' => 28.50,
                'expiryDate' => '2026-03-15',
                'quantity' => 0,
                'unit' => 'pcs',
                'lastUpdate' => '2025-05-08'
            ],
            [
                'id' => 6,
                'name' => 'Beans',
                'sku' => 'GRN-006',
                'category' => 'Grains',
                'buyingPrice' => 50.25,
                'expiryDate' => '2025-11-30',
                'quantity' => 5,
                'unit' => 'kg',
                'lastUpdate' => '2025-05-05'
            ]
        ];
    }
    
    /**
     * Get a single sample product for testing
     * 
     * @param int $id The product ID to retrieve
     * @return array|null
     */
    public static function getSampleProduct($id)
    {
        $products = self::getSampleProducts();
        
        foreach ($products as $product) {
            if ($product['id'] == $id) {
                return $product;
            }
        }
        
        return null;
    }
    
    /**
     * Get allowed categories
     * 
     * @return array
     */
    public static function getAllowedCategories()
    {
        return ['Grains', 'Oil', 'Pasta', 'Beverages', 'Canned Goods'];
    }
}