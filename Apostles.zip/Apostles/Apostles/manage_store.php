<?php
session_start();
require_once 'config.php';
require_once 'data.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Store data (mock data for demonstration)
$storeInfo = [
    'name' => 'Apostle Store',
    'email' => 'info@apostlestore.com',
    'phone' => '+1 (555) 123-4567',
    'address' => '123 Main Street, Anytown, USA',
    'website' => 'www.apostlestore.com',
    'tax_id' => 'TAX-12345678',
    'established' => '2020-01-01'
];

$storeStats = [
    'total_revenue' => 125750.00,
    'monthly_revenue' => 12500.00,
    'orders_month' => 145,
    'total_customers' => 350,
    'average_order' => 86.21
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Store - Inventory Management System</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="d-flex">
        <?php include 'includes/sidebar.php'; ?>
        
        <div class="content-wrapper">
            <?php include 'includes/header.php'; ?>
            
            <div class="container-fluid p-4">
                <h2 class="mb-4">Manage Store</h2>
                
                <div class="row">
                    <div class="col-md-7">
                        <div class="card mb-4">
                            <div class="card-body">
                                <h5 class="card-title">Store Information</h5>
                                <form id="storeInfoForm">
                                    <div class="mb-3">
                                        <label for="storeName" class="form-label">Store Name</label>
                                        <input type="text" class="form-control" id="storeName" value="<?php echo $storeInfo['name']; ?>">
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label for="storeEmail" class="form-label">Email Address</label>
                                            <input type="email" class="form-control" id="storeEmail" value="<?php echo $storeInfo['email']; ?>">
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label for="storePhone" class="form-label">Phone Number</label>
                                            <input type="text" class="form-control" id="storePhone" value="<?php echo $storeInfo['phone']; ?>">
                                        </div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="storeAddress" class="form-label">Address</label>
                                        <textarea class="form-control" id="storeAddress" rows="2"><?php echo $storeInfo['address']; ?></textarea>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label for="storeWebsite" class="form-label">Website</label>
                                            <input type="text" class="form-control" id="storeWebsite" value="<?php echo $storeInfo['website']; ?>">
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label for="storeTaxId" class="form-label">Tax ID / Registration Number</label>
                                            <input type="text" class="form-control" id="storeTaxId" value="<?php echo $storeInfo['tax_id']; ?>">
                                        </div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="storeEstablished" class="form-label">Established Date</label>
                                        <input type="date" class="form-control" id="storeEstablished" value="<?php echo $storeInfo['established']; ?>">
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="storeLogo" class="form-label">Store Logo</label>
                                        <input class="form-control" type="file" id="storeLogo">
                                    </div>
                                    
                                    <div class="d-grid gap-2">
                                        <button type="submit" class="btn btn-primary">Save Information</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-5">
                        <div class="card mb-4">
                            <div class="card-body">
                                <h5 class="card-title">Store Statistics</h5>
                                <div class="list-group list-group-flush">
                                    <div class="list-group-item d-flex justify-content-between align-items-center">
                                        <div>
                                            <h6 class="mb-0">Total Revenue</h6>
                                            <small class="text-muted">All time</small>
                                        </div>
                                        <span class="badge bg-primary rounded-pill">$<?php echo number_format($storeStats['total_revenue'], 2); ?></span>
                                    </div>
                                    <div class="list-group-item d-flex justify-content-between align-items-center">
                                        <div>
                                            <h6 class="mb-0">Monthly Revenue</h6>
                                            <small class="text-muted">Current month</small>
                                        </div>
                                        <span class="badge bg-success rounded-pill">$<?php echo number_format($storeStats['monthly_revenue'], 2); ?></span>
                                    </div>
                                    <div class="list-group-item d-flex justify-content-between align-items-center">
                                        <div>
                                            <h6 class="mb-0">Orders This Month</h6>
                                            <small class="text-muted">Current month</small>
                                        </div>
                                        <span class="badge bg-info text-dark rounded-pill"><?php echo $storeStats['orders_month']; ?></span>
                                    </div>
                                    <div class="list-group-item d-flex justify-content-between align-items-center">
                                        <div>
                                            <h6 class="mb-0">Total Customers</h6>
                                            <small class="text-muted">Registered customers</small>
                                        </div>
                                        <span class="badge bg-secondary rounded-pill"><?php echo $storeStats['total_customers']; ?></span>
                                    </div>
                                    <div class="list-group-item d-flex justify-content-between align-items-center">
                                        <div>
                                            <h6 class="mb-0">Average Order Value</h6>
                                            <small class="text-muted">All orders</small>
                                        </div>
                                        <span class="badge bg-warning text-dark rounded-pill">$<?php echo number_format($storeStats['average_order'], 2); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="card mb-4">
                            <div class="card-body">
                                <h5 class="card-title">Quick Actions</h5>
                                <div class="d-grid gap-2">
                                    <button class="btn btn-outline-primary">
                                        <i class="fas fa-exchange-alt"></i> Import/Export Data
                                    </button>
                                    <button class="btn btn-outline-success">
                                        
                                    </button>
                                    
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <?php include 'includes/footer.php'; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html>