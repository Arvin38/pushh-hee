<?php
session_start();
require_once 'config.php';
require_once 'data.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Get dashboard data
$salesData = getSalesData();
$inventorySummary = getInventorySummary();
$productSummary = getProductSummary();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Inventory Management System</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="d-flex">
        <?php include 'includes/sidebar.php'; ?>
        
        <div class="content-wrapper">
            <?php include 'includes/header.php'; ?>
            
            <div class="container-fluid p-4">
                <h2 class="mb-4">Dashboard</h2>
                
                <!-- Sales Overview Section -->
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title">Sale Overview</h5>
                        <div class="row mt-4">
                            <div class="col-md-2">
                                <div class="stats-item text-center">
                                    <h3 class="text-primary">₱<?php echo number_format($salesData['totalSales']); ?></h3>
                                    <p class="text-muted mb-0">Total Sales</p>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="stats-item text-center">
                                    <h3 class="text-info">₱<?php echo number_format($salesData['cost']); ?></h3>
                                    <p class="text-muted mb-0">Cost</p>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="stats-item text-center">
                                    <h3 class="text-success">₱<?php echo number_format($salesData['revenue']); ?></h3>
                                    <p class="text-muted mb-0">Revenue</p>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="stats-item text-center">
                                    <h3 class="text-warning"><?php echo $salesData['orders']; ?></h3>
                                    <p class="text-muted mb-0">Orders</p>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="stats-item text-center">
                                    <h3 class="text-danger">₱<?php echo number_format($salesData['avg']); ?></h3>
                                    <p class="text-muted mb-0">AVG</p>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="stats-item text-center">
                                    <h3 class="text-dark">₱<?php echo number_format($salesData['profit']); ?></h3>
                                    <p class="text-muted mb-0">Profit</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <!-- Sales Chart -->
                    <div class="col-md-8">
                        <div class="card mb-4">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <h5 class="card-title">Sales & Purchases</h5>
                                    <select class="form-select form-select-sm" style="width: 120px;">
                                        <option selected>Monthly</option>
                                        <option>Weekly</option>
                                        <option>Daily</option>
                                    </select>
                                </div>
                                <canvas id="salesChart" height="250"></canvas>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Inventory Summary -->
                    <div class="col-md-4">
                        <div class="card mb-4">
                            <div class="card-body">
                                <h5 class="card-title">Inventory Summary</h5>
                                <div class="row mt-3">
                                    <div class="col-md-6 mb-3">
                                        <div class="d-flex align-items-center">
                                            <div class="bg-light rounded-circle p-3 me-3">
                                                <i class="fas fa-box text-warning"></i>
                                            </div>
                                            <div>
                                                <h4 class="mb-0 text-dark">237</h4>
                                                <p class="text-muted mb-0">Quantity in stock</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <div class="d-flex align-items-center">
                                            <div class="bg-light rounded-circle p-3 me-3">
                                                <i class="fas fa-clock text-primary"></i>
                                            </div>
                                            <div>
                                                <h4 class="mb-0 text-dark">0</h4>
                                                <p class="text-muted mb-0">To be received</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <h5 class="card-title mt-4">Product Summary</h5>
                                <div class="row mt-2">
                                    <div class="col-md-6 mb-3">
                                        <h4 class="mb-0 text-dark">6</h4>
                                        <p class="text-muted mb-0">Number of products</p>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <h4 class="mb-0 text-dark">5</h4>
                                        <p class="text-muted mb-0">Number of categories</p>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <h4 class="mb-0 text-dark">0</h4>
                                        <p class="text-muted mb-0">Number of suppliers</p>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <h4 class="mb-0 text-dark">8</h4>
                                        <p class="text-muted mb-0">Number of quantity stock</p>
                                    </div>
                                </div>
                                
                                <h5 class="card-title mt-2">Quantity Stock</h5>
                                <div class="mt-2">
                                    <div class="d-flex justify-content-between align-items-center p-2 border-bottom">
                                        <div class="d-flex align-items-center">
                                            <img src="https://encrypted-tbn0.gstatic.com/shopping?q=tbn:ANd9GcSw4YY1a_ZXwEPUwmSS9VqDR3j8TUaKcKimOwlLsOsY6RoVHw_bEHN7vJP3YXjQiWclQtez9FogNQO6WK75ESnjaQiVhMCxS-RKccr9G4J7Cyg0C0TLnhD2Vw" alt="Pasta" class="me-2" style="width: 40px; height: 40px; object-fit: cover;">
                                            <div>
                                                <p class="mb-0 fw-bold">Pancit Canton</p>
                                                <p class="mb-0 text-danger small">Out of stock</p>
                                            </div>
                                        </div>
                                        <span class="badge bg-danger">0</span>
                                    </div>
                                    
                                    <div class="d-flex justify-content-between align-items-center p-2 border-bottom">
                                        <div class="d-flex align-items-center">
                                            <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxITERISExIVFRUVFRkYGBgXFRUaGBcXGBUaGRsdFhoeHSogGBolGxcYITIhMSktLi4uGh8zODMtNygtMisBCgoKDg0OGxAQGy0mICYtNS0rLy0vMDAvLzUvLy0tNS8uLy4vLS0yKy0tLy8tLS0wLS0tLS8tLS0tLy0tLS0tLf/AABEIAOEA4QMBEQACEQEDEQH/xAAcAAEAAgMBAQEAAAAAAAAAAAAABQYDBAcCAQj/xABKEAACAQMCAwUDBwgHBQkAAAABAgADBBESIQUGMRMiQVFhB3GBFCMyQlKRoWJygpKxwdHSFRckU8Lh8DNDY6LxFiU0NkRUZIOj/8QAGwEBAAIDAQEAAAAAAAAAAAAAAAQFAQIDBgf/xAA9EQACAQIDBAcGBQEIAwAAAAAAAQIDEQQSIQUxQVETImFxkaHRFIGxweHwFSMyUvFCBiQzNFNicqJDgpL/2gAMAwEAAhEDEQA/AO4wBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAOb8Q41XV3xcVQA7DbRthjgSvlXmm9fgelo7PozirwWqXFmjccZux3lvKunJG6pseuM4398w8RUWt/JHeGzcK+rKnr/AMn4mtU5hvAdrup91P8AlmPaanPyO8dkYSS/R/2fqfP+0t7t/aqn3U/L8yPaqnPyMvY2E/b5v1Pa8y3njdVB+jT/AJY9pqc/Iw9kYThDzfqezzXeZGLhhv8AZpfvSY9pqcwtj4VL9Pm/U9PzheZOmsceqUj/AII9pqczMNjYW3Wjr3v1Pq87Xo/3in3ov7sR7TUMvYmEfB+J9p+0G90g4onPmjdPDo89bh9mQlSi6l8zV2fMMZtRxxM40bZE2lfktL+8y/1j3Q60aJ/XH+Izd7Kp8JM5x2tPikZF9ptbxtUPuqMP8Jmj2VH93kdVtV8Y+Z8/rSq7/wBkXI/4x/kmv4Uv3eX1N/xP/b5mGr7VK46WtMe+ox/wx+Fr93kZW0m/6fMxr7ULsgsLalpGMn5wgZ6ZOdszH4bC9swe0JftMNT2o3nhSoD9Gof8c2WzafFs1e0J8Eid5M5zubm6WlV7LS1Nj3EYHUMEblj4ZnDFYOFKm5RvvOuGxc6lRRlY6DK0shAEAQBAEAQBAEAQBAEAQDkvF3+dqg4/2j+J8GMrJ/qZ7TCxTpRa5L4GiUZgQqnbcb7DPpjfb1nPgS04wldtffbc1lprhtTkMMYXSd999/Aia6HdyndZVpzuYqrYO34/9Zq2bxTa1PiVCw/yi4cUiU4Jws16qj6gI1EA+J2A9Tv+J8JznUUFd/fL3shYzFKhTb48PXuX0Lk/J9rknS49AzbTnatLe8vZa7KBbYxNrXXgQXMXJxVGa3LNtuh648dJ93hJOGllqx6XWKerS+R0qbYrSw1SFuu4tRa5nPuJcRKAAdzOfpLvt6eH+uk9FW25Wm/ykkvF+h83p4Gz62tja4Tc9qi506ixAIyC3lkdBvtLfZ1erVo9JVfd7iPXo5J5Yo9NUGdpY3Rooy4n2hReq2mnTZ28kUsfjgbTSdSEFeTt3nSFOctIps3LzgldDSV6R11SdK5UnbAOcHA6/gZxhi6M02nojrPDVYNKS1e4sPBqFHsza9mQ4qU2NNsBrioqsSMjbs1bT7lBPVpXVpTzdKnpZ6rgvX5k6go5eia1utH/AFPv5fLtZD8Q4HSqM/yZ9TIuqptinv8A3eN0OvuCmRk7eck08TNJdIt+7n7/AItnCdGN+pK9t/L3e/RLeYuTqz0eI26sCCKvZsD1BYFMH3E/hN8VFTw8muVzbDStXiu07lPOnoBAEAQBAEAQBAEAQBAEAQDl3GLY/KauFBxUY4yN+9ncSuqR6zPXYWrahG74L4GmtRqbvp22UYPRhgbH39Zxbtck5Y1YRzdvu3khU4RSK9tjIxl1YsGGcbowO438d/fIFWpndqUrPl9/yR44uqn0Xg1a3vRHXHBgxY027gzudyDgED1zn8JxWNcEo1F1iXDGuKSqLUhGp6T3mAHiSD4Hy65k5SuidKsst7HQOTLii9vTehqCFmyXADM6sVYnBI8Nt+kpsf0vtUU3ZRs1377nksZVlVm3P6JFwTpPR0NYplSz6aYkpQW8xc4l7VeEhL0sM4qoHHpjusFHvAPvaRJvJK3ArMcsk1Ln8TW5XWk9RaIpVWJ+iFUEnHiTnYeZ8J6KjtiioKnBNW03ehU9BKpPn3E3zBxqzoVnNFFr1erb4oK+N9xvVOcnqF98hV9rzS6OHiSJqlCd0rvyXqVjiXNlzUXeqVX7CdxAPzVwD8cynnOpVfXdzHTVZaX07NC23NErTsqR1I9O2DMwP0WrEuwb7wD756rZNFQw1mt73HHHTlCUIJ2aXxPFtcozhK+kFmVTUx9QfYJOKTFiWLeJOeo702dGUVmp+H3v5JHGniFJpVOzXs+WurfvJS3vmtmZqhLq+p+0VNVbWtNVUMW2CgNkMd998ZIkeVJV0sujWluG/wC7kqGIlQk8+qet7a6JJb/vmQtheivxCxVaYpolUaVG7bZcs7dXYkZJkmtS6LDzu7t7/ouRrhaiqV42VkvvV8Wdmnnz0QgCAIAgCAIAgCAIAgCAIBz7j9tpuapOQGORjPiBn9sr5Si6ko8UejwdTNQilwIh0xUqE/VxjO++VkWtpdFjB3pxtx+pK2iGq/eJCAasjy+z++UtWqqKeXe9PqRKslSjpv3fU2fk+HVaakoTjAA29T+Tv+EhJOs7f1cO049JeDlN6/fmRHOHJNxc3VFqTotLRpqls5GGJ1KAMMSDjBI6CXWAboRdGUW3wfDx4dhBji5paPTkWrgXBktqFOinRPH7TE5JPqSTMzp9I80t5xlUzNsnKDbSzw/6bIjS3maS1c0Oce1KirXfDlP1u1BGPq6qWZExkG1oQNoRbhHvKdzpcG0U2NDCsVBunXq7MNQpKf7pQRt4k7+OUYqmsnHiRdKS6Jb+L+RXbJSlA3FQbFuzpA/WfGXb1VFI/SdPWOjW806FKObwJHkngny28p08ZpqddXy0Keh/OOF+J8ptSheRthqOafYdn5i4J2wOnZj19cdBLzC4nonruO2OwXTLq7yl3/CKVNWSrVy43CpuR5gsdh+Mt4V5zd4R05sopUIUrqcteSIildV3DBBUK6NLY1v3M9GPgM+4Tu4UoWcrX8DmuklfJd6W4vQy8lEPxO0CkMFapkggjK0X8Rsd8TjjpL2eT7viWGz6U4VkpKx22ecPRCAIAgCAIAgCAIAgCAIAgEFxW2UmuWHgpU9SNgDgfASBOMVUnLjZWJ+HqSSgo9tyrccs2Opl6bDG/wBpSSfCV0666SSZdYKsk1F/e89cMrMQAgARdPXIJB8emJU4ilG95vV+QxEYxd5at3Ldw200jVtlh+HpLHZ2CdOOfmUdermduCNspJ6o2OFzGVmuTgbXPdIYMkUVlZrI5DX57uqFd2Rwyajmm+69fDxX4GQ8JWqJXbvfXUoJYyrGq7PTkbd1xheIXVpc09moBg9uSQ5DFS5osNqowoyuzbdDJrln3eH3vO9Wv08YqO9O9ufcU7nSnUHEbtDuxuGIHmHOpB+qyzSpHrs4V4fmvvJDm7hpa7pcPoLq+S0Vp4GAuth2tWoT0UZbdjsNM6Si86hE61YyzqnHgiU5a5wteH0Xo2tvVu6mr5ysuyVGA+ocFuzXcDIGdz4y7o7LcYrpJJP77iXTtTVlv4mPiHtjuC2lLenT23DFi+fwwPhJcdn00rttm7m2VK/5zu6mrBp0yT1pIFb4Pu34yQqaXN9/ocVh6ad1FETqqV2zVqO/mWYsTj3+6SKVJyfJCpNQWm86X7M7PRf2pxgNRqMo8lGpPxIMj7RkuhaXBpfMi4W/T68rnaJ58thAEAQBAEAQBAEAQBAEAQCF4sgJrA+NMeXr0lbWqRVWcXvyom4dtKLXMqlG6akzUicqD3SPE5H+UqMVSU4treXTpqolUW/ib1mtUuGZVXJATByc/lDpjAz78Tjg6dOpK0W3bffn2HGs6ahaLb5lvpjAA8p6CkssVHkUct9z3O6XI1K5xbnXh9DIe4VmH1aeahz5HSCAfeRJENn1qmqj46DNYqdf2wWwqIqW9XQXUM9RkQKhYBmCjVnAycZHSSo7JlHVy8DV1Chcx2vZXdak+QFqEZG50ndWA8e6Q2PGeehTyPK+BQTp5arT5kfc0alFwrbHAdGU7Mp3V6beI8QfTwIM3asxODgy58BB4ncW1VsG5tqlE1ug7e3WoPnPLWnRvMEY6YnePXab3reS6T6ZpvevNFp5lotT7Y29OjSFZy1W4uCnfOchUDdUHgAp6Z67nksVNycqKsv3PS/d2G2Jc4tqFknvbfwOccV4jUBOeJu7D6tM3Oke7UFAHuEzmk9XK/iRk5WvnuaVrzDdkin2rVwxwKdVRXDZ+qEcN19N50hXqQfVbN41KnA2uabS0p0l10loXxbvUbeoWpIu29ZWyKL46U1byJx0npNnzxFRXqLTzJ2uXrbyDsaLO6U0GWdlRR5sxCj8TLlyUItvciPJXZ1DkUj+lEUAAJSZBg5B0UwpIPkWDH4ytxqfs13xd/Ei4OWbFNrlbwOtyhLsQBAEAQBAEAQBAEAQBAEAheJZatoUaiAD6D1JlPi6bnX05E6i1Gnme4h7i0SnVwUepVK68IhPdz9U9MAgDxPe9ZHeCqzvbdyv9/A7+23WW9kebGutV1qKcGnkPTIZTTYddQbBU43wQNjnpiMFBU5KhKLUtd/HtR0lUSpSV9HxMHMHPBSjWq2VA3K0sq9fUooIwwT46quAw+iMes9VhtmpySrSyt7lx+hTOpyOUcU5qu7wsa1ZtOdkU6aYH5g2PjucmXtPCU6OkV6nNSbIhvUj4/wnaxlmnXUb43xMOJzbLVw2vTvqNOjVqLSuaK9nTqufm61MfRSq31HXor9CNjvgyi2hsqU/zaK70R8TCMtW7MkrPhF3SX5NdWNevbkkqaSl3pE9WoVFyu/UoTpaUNpR6s4v0OEVOKyyi2uz5Fo5N5MazvFuu2BoGm4UOj062WwAr02G2OufTpvJFDDyzXWqOsVChLNKWnbozb5y4B8ofWlym/hV1DHoGAO3pgSJLY+Ic3OLcr89/wDBAxs6FSpm6WK7/Uo9fkylTOq4vEx9mgj1Gb3MwVVPvllhtj4mejVjFPEYdaOon/x1Ii/44KAanY0/k4IKtWLa7lx4/OYApA+SAe+ekw2xKNBZp9Z+RY0aia6it8Sq0zgk+f7fWTVCzOpbuTLQHtLh/pIMUhjrUbIL5/IG4694r5TnWTbUFu493L3lfjcSqMXze719xcvZ5SxxGmf+HUH4D/ORdpf5d96I2yp/nW7Dr884ekEAQBAEAQBAEAQBAEAQBANO6rqhJ8TiVmKq9HNuKuztTg5ojO1Zrq3JXAIq4yMHGkfwH3TngK1WdWTmraaeJtVjGMbJ6lc9rnDKnyZq9EkA6VuAPr01JKFvMKzH4NvsJ6fZsodLaS14Mjtu1itcpf8Al3iY8mqn/wDKmZKrv+/w93xZzX6WZvZfydaXdm9SvTYuKpXIqOMjSrDYHY96Yx2Mq0quWL0tyNoLQ1uIW3LKtVpl6wqKWQn+2NpcEr5YOCPdtOlOe0Gk0lb/ANTR5TV9lHIlK8R7m6y1NG0KisVDsACxYg50jIAG2d8zbaONlSl0dPfx7DEI3NriXEOXia1FLd6VSmHCVR2iqaiggdHJI1DHeXE0pxx0bTvdPhoZkoSVmj7ylxbhJpW9GvUuWuajBW0VbxE1u+FHcdUAGVGRtGK9rTlNJZV2Renv1NIUaUVZRRauZ+GcKsVSpcC5AdtIK3N6xyATvir5AyJQxGKqtqFvCPoJ4ahvlBeBB8iWtle3d+qmtUoL2T0dVe7VlVlIdWzUBI1g4zk+sk4uviKMKd9G730XD3cmaLC4dv8ARHwRl4/d8Atripb16FZqlPAbeu47yhhuam+zCYpPH1YKcJaPuRt0VCDsoLwRyisqNdEUe9SavikGHVGqdxWB9CAZbSqVFRvPelr4BRidt5h9l9hXRloILeuFypQnTk5xrTONJIO4APrKChtOtBrO7rt9Tq4RZTLCmgphEpmkE1KULFitRWK1NTfWOsHfyA8BL2O7M3e+t/h5Hjtp1JPENS4biZ9nwb+kEzjZH6D0kbaX+XfeidsrK66tyZ1qebPTiAIAgCAIAgCAIAgCAIAgFf4ltWY5G2nbHoPGVVeadSa+9xYUdaSRHvxhX4tb2yjelSqs59WVNKjz23J9R6yfQwzjho1pb20vdqQJS1se+S+MLeW9WhWwzIz03U766ZJAz593un3GSq0HQq2XFXj8/B+VjUr1Dl9rLhvGbZslMs9Nj9ak1JcE+o0lT6qZLWIVbGQlxtG/fdmLWNj2JMfktwCc4uPw7JP4TG03/ebf7V8WYgUjnngfC6YuatvfNUue2JaiWQjLVfnAAEByuSevgZZYLFVpuMJQtG2+z4LTsNZJG57KueaNmr2tyStNn1pUxlUJABV8dF2zn1OcbTjtTB1HPpoK+mq495iMrFq5r9m9pfK1zZutOq+WypzRqk75YD6JP2h55IMjYPakqaUZax8198n5Gzipao43w6k9G9opUXS9O6pqynwZaygj7x1lzjZp4Sco7srfkcbuNzrvt3H9ktT/APJ/bRqfwlRsn/El3fNHapuK97CamLy5X7VFT+q5/jN9sS1pL/l8jSD6xIe0mz4N8ouzWrVUvTTBAC1imvsQKfRCuCAud/Ob4GvioxioxvC/Lt1M1Mt9d5RvZvYdtxO0UjIV+0PupgsP+YLJ+1anR4Zr9zS9fJM5Lejs/C1vP6Yu6jUXFq9NKauSoGaQyCFJ1YLPU3x4CUFZU1Rp5X1ru67/AOPM7WlnuV7maw7G/rgfRrgV1/O+hUA/SVW/TlzgKuegl+3T5r09x5vb9C041Vx0M3JAHy5fzH/YJjaX+X96OOxH/ePczpk88evEAQBAEAQBAEAQBAEAQBAK/e1NNWozHujvN6Kq5P7DKpx6TEuK4tL4E5NKimc15Pu2bjmt/pO9TPXo1MkAfAD7p6rHwUcNTS3Jr4MqnLrLv9SN4dxGta3lWvTUnTVqZGcBk7RtSgeJO33STjMG8Rh45P1JJrvtu7nuMOpFO19TqPMt/Tu+D3dWidQa2qHbqMISVI8G2O0p8BNOvBvTrK/ZrxOimpR0Kt7DrwYvKJPe1o4B6lSukkfECSdrxtjH2xXxZypS69ny+b+hCX3suvql3cOxopRqVqlTWXJIRqjNnSBnIB6fjLOntSjGlGOt0kre46dG7la5e5MqX9KpUtatMvTfBpVCVYoRlWB3G/lge+bT2nGlXlSqq1rWa7V63OKV5uPLz+2dR9mHLFzw6ncPd1ESm2GCB8rT05LOzHCrnbp6mUuPnSq1+kpLhZ9v8HaEGndnI+YeIC64pUrUQSKt0nZ4G7AOqqcflaQcesuq9N09nSg9+R+f82OFbVStyfwOre3Wix4fRYDIS5Qt6A06i7/FgPjK/ZDXTNPivmiRU/SU72KVv+8SPtUX/AqZvtiNnTfecIv8yPvLLz97Obi8vmuaVagqOqAiozhgVUL4KQennNsFtKnRoqEk79h1nFN3uaPIPDLewuLy6qV1ejbIKJrAYV67HLpRGSXKgKnmWJnHHYiWLlThFW4279Ffz9zRqopSu9yMHMfM15V/tJqvRCOrU6CHC6dQ2q43quQdx9EeA2yZNbZ1OGHmlrKz17Vr4XKee05Vq3R011bPXtXHuuXP2hUw1CjdDGqicuMjUKVQAOOv1SEY/mGRNl1ss8r/AKl58PQm7QpLEYdxW/eiB5Kul/pGkmd2Rz8NBMs9oxfszfain2NSkq6lw1R1WebPViAIAgCAIAgCAIAgCAIAgFX41ZswuAF1MwOkZ65wOnxMq8LOLx+tlZ/BEyc/yUlyKDX5VrCtVqPSqknG6rUCjCY7rAA+mZ7SNTD1KcYyafYzzeIq17vLF2XYR/EKIoKqFcPpBwxOQGGRnPU4Od/ST6Fprq7lp4EZTlmvPeRPD6dWmzVKdWpTL9dDsur84dG6+U0xWBw1WWZx63NaPyJdOpfV7yErgowKsysvRlYq3TzXBkmphKNaKVSN7brnfNc9LdVSrk1qxztvWqn78tOL2dhk9II3TRGrVKtqRmVh9ZGZW+9SDM18JRrf4kUzLs96Pd7xGvVGmrXrVF+zUrVHXI9GYic6WBoU3eMfmZuYLek7sFpq7P1AQMW+AXeSKsIShapa3buNSft+Tr+ouqorUafi1zUZB127jZdj7lMhJYOE10cU5f7Vfz3eZrKUYLNKyJiw4FY0e9UNS7qeW9GgPgD2lT3EqD5TarQqYiymkl4v0XmQau0aaVoK/fu9fgeLjg9s5J7FBnyGw9wm8MFQj/QvArvbMRe9z7ZWFOnpABOnOnUzMEz10AnCZ9AJ2hh6cG5RWrNK+Kr1VaT07NDbuqKPjWoYeAO48uk3cVJOL3EelKpS/Q7XPicJtxj5in+oJwVCmt0V4I6e01/3snORkH9I0cADSHHw7Nht8TOO0n/dpe74k/ZspOurvn8DsE8uelEAQBAEAQBAEAQBAEAQBAIe8pgu2Rnf9mPCeLx1eosVOMef3xJtNvKjVt6p7Qg5GDsN9xo658N/2TlRlGNVyb0372nuenM7TiujTX3qe7khzhlVx+Wqt7+onJ7axdGo+hqyy8L29Dl0FOS6yRoV+BWr7G3pgDpo1Jj4KcH7pa0P7Z42Gs9fvtuR5YCi1orHOuK0uGl6qJRr51soIrKAMbZGVORkHbB2PXoB9O2fWxeIw9OtJpZknZq718OBS1qkKU3FJu2hrDh3DtKUyt2zkEaUNNizHJyNgSwHhjHpJUnidXeCXN3RrHExemV37LGweF8PtkzW4XdsT9GpcVKqBiegIVVQbeAGf2zjHpq0rQrR7kk/jqdJ1nBXcGRVKtaL9CxoZPU1DUrDGPqh2IXffI38OnWZ7LN/qqP3WXwIksXUe5JG8nM9dQVpMtFCANFFFpqAPLAz49c5mFs+jvkrvm9TlKvWfG3cR5rnOfE9TJOW2hE6LU+fKDM5B0R9W4Pn8JhwM9GZu1zNLWMdGfaVXvAHpkdOuMzLXV0MdETNR6ROUVlXw1sC3xwAJEippdZ3fYazpq/V3GXlGtp4nbgfWLD/AJGP7pyx8b4WT5epOwEbVY/fBnZp5Q9EIAgCAIAgCAIAgCAIAgCAQd3VU1HAbdWGcH3Hf754/G0nHFVJO/Z4In04tQTtvNIVSK2knqCQd/u98rMufNOCd1ppv7yRlvSzGwpOAcdfhK2UUpNPgaPeaHH+IG3tKtUkalTbyLnur/zESbs3B+3Y6nQgtJSXhx8jlWmoRclwOUcCtHrVadGkNVRzgZzhQBuznyA3P3dTPv1ecKFLM9Ir7SR5iNF1JWLhxnjVHhYNtaANcYxVrsASD1wP5eg9TmVmHwtTGvpa76vCP3/LOlSpk/Lo6c36fenw1OCXVzVtb25u67NbGg9NVd8h6xwVKL9UqR18zt0M3xEKUK1OlRjaSabaW5fUwrxpSlJ3urK73soyUKpptVFNzTVgrPpOhWPQFugPT7x5iXXSQU8l1d62OPRO1+B5tEeo606al3cgKq7kk+UzOcYRcpOyRhUm3ZH24DU3am4KupIZTsQR1BEzCUZxUou6Zh07OzLjwDhdvQsW4he0+07Tu29IkjV1Go488HHkBnxGKjEV6tbELD0Ha36n9/dztkjSp5pK7e5FN7bfbbyGc7fvlvbQ4ZDMteYymHAleBW3bVDvuq5UAZLtkAD0HU59JGxE+ij2cew0lHSyLHU4SWqns+8qjfzGBvn3GQY4lKCz6NnNw35TV4XSNPitltgM4I+IZZtiJKeEqffIlYJddHaZ5MvBAEAQBAEAQBAEAQBAEAQCu3qAVqhJ8c+4aR/DM8xjZy9qlFP7sWVJt0opGsLhdQOQwJONvHBlRSw0unmt1r3O7pyy23G8KidmHznw23/6TT8Oh0EZOVp66c9eHuI9pZ8tjn3tQ4qOzoUFO7MajYPgowoPoSxP6E9X/YTZzeLqYia/QrLvl9F5kXaDcY5eZ59mLLSt+I3uMvSp6V9AFLn7yE/Vnutq3qVaVHg387FXHqU5SW8pHDLateVxTTvVXJZiTsB9Z3PgozufcNyRLapWhh6eaW5bvRHFUdLIufOnCRb0LKxtKRrNWzVZ1TL1nAABz4DveeAMe+VeBxHS1KmIrytbS3I2qQvKMYbrX7yz3VmtvbW/DaVEXNXCl0x80GY5NS4/I1aiFPXHoJXwm6tSeJnLKuD490e22lzervjSgrtb+S7X8UvfyMttw60o3t3fjs6dOhSFIlVAQVcZqMFG2rSaa7faYTWVSvUoww+rcnf3cPmzZThFyqcFp7/507yMr29K8snL260vlddEt2Kjt2y4BrOx3yRqOOmlR4GdlOVCussr5E837e5dm5d5zinkUZLWT0XHm23ztdvwI3mS2N/xSlw6jlaFsoUlRtTUKNR9+NKD1xJOFqLCYR15ayl5/e9jL0tVvgtF8/PT3EhxKtZqlTh9nSp1nZCgRFBCHo1a4rEbFfftjzIA40o1nJYiu2le93vf+2K7TWc3K8ae7yXa3z5W05nLK/cdk1BtLEalOVbBxlT5HrPSRlmSdjmkmroz2HEHpOHU7j8RNakFONmaypponeH8ecGjTVmKu3zinoWZsfsxvIlXDRalJrVbmc1StfkXrma3/tXCbnSEzXWnpH2SwKfhq++UmGnalWpXvpf1J6V3GVrHQpTE0QBAEAQBAEAQBAEAQBAEApXMVeqLioEH2d842KjPpKqvQp9K5ON3p8C7wkYujG/b8SItbxzW0BcBRvkZJ3PTP5wkOVOKk5vt8yxnRgqOZvV7iwV8UqQGMGp3gQdwDgk49dhNqtN06ChKKfL4lbT/ADKl+Whxrmq+7W7rNq1BToUnGcJsem30y095/ZrCez4CN1Zy1fy8in2jUz1muWhk5V5lazNZSi1qVZdNWkxIDDBGzeBwxHTx92LTF4VV7O9mtzIUXo0e+IczqtFreytltKT/AO0IdqlWp6NUbfT129ZrDCvP0lWWaS3cEu5HOUXPR7uXPv8AQl/Zrx+6qXdpZm4bsAWOjbolNnChsasZUd3OMSNtGjRjSnUUVm5+86xTk1duxp8d5xve2uBTuGWm9RsBdOy6sDS2MgYHgfOScPg8NkjeKbSIyU3HVvXXxLDWva1vZcKtrcBqldDWYFVfW9Q5wQwIPec7+gkOFOnWrVqtXcnZcNF9EdJNxlCEdyXx0XzNK7t+KvXoXdRaruj5pKyDGVySAoxgFQ3rjM6xng1TlRi0k1r/ACbRg1LNvfaeOL80XtvV7alZfJFaqXqEo7CtU3BFR2AyNzhdsb46TFHCYerHJKed2stdy7F8xacZX3Ll38zW4jdcTr09FKy7ClW75W3o6O2z3tTfWcb5+M6U1hKUryneS0vJ3sYlSlLfu5cCp3NlWpqGqU3QFmQFhgakOHX3g7SyhWpzdou73+IcWt5iU9J0uaNG3QJV1JyMYI/cZo2pKxpa6L5xHjrXFxw7wWlWogY8+0TJ/CU0cMqVKrzafwZ0g22r8DsM80WAgCAIAgCAIAgCAIAgCAIBRubLZvlJbtCoZRgL1JVZU4mb6ZxXJHoNnVY9BbLdp8SE1lWGG0sWXGdzvt/r3CRdXJq2hY2Uo3aurPuJHiPEatHh1e4cYxT7OkMeLMVJ+O0m4XDynKzW/qr3sq67pQrdXheT9y0RxCpVJ8ck+PnPo1KOSKity0PMTlmd2fFVs9NxufdNpy0vcwlqYy/rOF2zpuM1ndtSdKlNyjodSspwQR4gxKKkrNaGDNb1nZj3WfUSTgE9TkkY6bzDsuNglZWJ+hUuqT2xArOLdgyLpcFVDhiucZCk7Y8Mzi3CSkrpZt5nLZ3Jipzm7VqVWtQq5pq6HFTuaGp1EB7J0KhwGGScg6DtuZxjhYqDjGS1s93auKd7Gb63sa1Xmm3e3egaNYqxZdQqUwADXFfIATTqBGOgABM3jSnGqql14PlbmG7qx44XzJb0eyXs3ZUo16RJFIsRXqI4JVsowGkjB85vVpTqXd1duL48E1w14msXYx8Y45bvaLaojFaZD02xhg/aVi+vYAgrVHQdR4+G9GEo1nVb1ej7rK1u5ow3dWsSNn7OrwsroaWnCsC7YO4BwVwfdMS2tQtZ39xh0W0X665OW6xUuiBW0AfNlAuR08MmVUMe6PVpfpvx3mPZ5O7bOeXtDsbuimnGmsgxnx1jGPwlt0uejJrimaQVnZneJ5UnCAIAgCAIAgCAIAgCAIAgFG52qMtcEAn5sYG+N2Oc49B+MqsZH83Tkeh2Wk6OvP5Iq91XOqmxpkMHB2zuMYPXz2+6Rcrbd3oW0ILK0npYe1a9Y21rbqW74FVlA20gd0E+Y2OJ6HYVN9JHM9yv47jy2LtGE7LVu3hq/OxQFZVZSQpwQcEZBweh/hPTasrNCRbi++1pbZxgt2e52xnGcZ+E16NWs5PxM31ukYv6dro2pEoqNu6tJQoGXP0Tt/vW/CY6GDXHxF2ZKfM9wARrXOSchEHVQu+Bv0iVCD4BSdjVuuYbo4HbHGkDYJ5Y8s+HX1myoU/2mMzPdDmO7C4+VOoAAUZB3wBn06TaVCl+0wpS5mza8xsVQVatUujgq4NNh1IbKsv2GYDcjJ9JpKgtbJG2YzNzIgzircZPUjsB02GwTyxNFh3yXn6jMj0OYaRDBqlY62y3dtyD3Qmd166FUZ95joJX0S8/UZit265dFz1ZR95AkmTtFs0P0ZWqgUk2GwWnnJ3+aDbDIB64++eZiryO5ltaTKoZ8k61AGrBwWAz3WII9D1wfOYk03ZA4rx3jmu5Z2UkJcioNIGplVug9TjbeehhTtRyrlYiuPXzH6AoVQyqy9GAI9xGRPNNWdiUe5gCAIAgCAIAgCAIAgCAIBVuaL8JWVdOdSADfpux39MCVG0P1p8kW2AoZ6blfc/Qwalxl0xpGPAgkjIAPiPhKCsqs5Z1u+/PsOyUt0HvOW+0PijveFQcCkipjORnGo+A+0B+jPon9m6F8Gqs3dy47tFp6lRjZ2nli9F8ys9oT1OZ6JQRDuYXJ8zMtJGtz6ogyfDTgweDTgHlkgweJgyj7iAelEAzW4IIcDOlgfuOf3TEtVZg7JYe0Kwqoqv2lNsqSrJqGoKFyMegHjKSWz60XdWZ3zo2m5ytKeez1VCcYGCgHUjOTggZmnslSX6tDV1Eij1LMVg6YxqbIwc4Jbx6Z2JEsc+TUjZtTuqKAAB0AwPcJ50mnqAIAgCAIAgCAIAgCAIAgFa5j5fq3FZXWoEUIBuTuQzHpj16zPQ4aavVTb7ORyniNoU3lw04xj2q7v6WsaB5bvNgKtLA/wBfYmn4fs1u7hLx+pEdfbLf+LDw+hC1PZiXLM5plmYsTrqHJYknPTG5l1Sx9GjCNOnF2WhGdDaU23KpG/d9D4vssGMYpfr1f4Tr+LQ5PyNFhdo/6kfv3H1fZYB/dfrVZj8VhyfkZeEx7/8AIvD6GRfZljoKHx1fwj8Vhyfkc3gMe/8Ayrz9D3/Vr+Tb/c38sx+KQ5Mx+H4//V82eP6tj9i3/H+WZ/FIcmavZ+0P9XzfoeD7Nz/dW/3n+WbfidPt+/eaew7S/wBReL9DG3s2P9zQ+/8AymfxOl2+A9i2n+/z+h4Ps4f/ANvR+8TP4nS5vwNfY9p/u/7GP+ruoP8A01L9ZJn8So8/Iw8JtPn/ANjKORKq9LdPgafn75j8QpPiYeD2hxb/APr6n2tybXyCLYEjG47LO36URx1Lc5fExPB47hfxXqbVHl+6Df8Ah8D/AOv+acZYmjbSXxN44bGX60X4r1Mx4BdbfMeI6On8Zp7TS/cbLBYm/wCnzR0KVB6UQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEAQBAEA/9k=" alt="Juice" class="me-2" style="width: 40px; height: 40px; object-fit: cover;">
                                            <div>
                                                <p class="mb-0 fw-bold">Nestea</p>
                                                <p class="mb-0 text-warning small">Remaining Quantity</p>
                                            </div>
                                        </div>
                                        <span class="badge bg-warning text-dark">3</span>
                                    </div>
                                    
                                    <div class="d-flex justify-content-between align-items-center p-2 border-bottom">
                                        <div class="d-flex align-items-center">
                                            <img src="https://medias.watsons.com.ph/publishing/WTCPH-10085427-front-zoom.jpg?version=1720770909" alt="Soap" class="me-2" style="width: 40px; height: 40px; object-fit: cover;">
                                            <div>
                                                <p class="mb-0 fw-bold">Soap</p>
                                                <p class="mb-0 text-warning small">Remaining Quantity</p>
                                            </div>
                                        </div>
                                        <span class="badge bg-warning text-dark">5</span>
                                    </div>
                                    
                                    <div class="text-center mt-3">
                                        <a href="inventory.php" class="btn btn-outline-primary btn-sm">See All</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Product Summary -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">Product Summary</h5>
                                <div class="row mt-4">
                                    <?php foreach ($productSummary as $product): ?>
                                    <div class="col-md-4 mb-3">
                                        <div class="d-flex">
                                            <div class="flex-shrink-0">
                                                <img src="<?php echo $product['image']; ?>" alt="<?php echo $product['name']; ?>" class="img-thumbnail" style="width: 80px; height: 80px; object-fit: cover;">
                                            </div>
                                            <div class="flex-grow-1 ms-3">
                                                <h6 class="mb-1"><?php echo $product['name']; ?></h6>
                                                <p class="mb-1 text-muted small">Price: $<?php echo number_format($product['price'], 2); ?></p>
                                                <p class="mb-0 text-muted small">Qty: <?php echo $product['quantity']; ?> in stock</p>
                                                <?php if ($product['quantity'] <= 5): ?>
                                                <span class="badge bg-danger">Low Stock</span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <?php include 'includes/footer.php'; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="assets/js/main.js"></script>
    <script src="assets/js/chart.js"></script>
</body>
</html>
